-- Analysis queries. Run all of them with: python sql/build_database.py
-- (the title line above each query is printed before its result)

-- name: Average CO2 by brand
SELECT make, COUNT(*) AS variants, ROUND(AVG(co2_g_km), 1) AS avg_co2,
       MIN(co2_g_km) AS lowest, MAX(co2_g_km) AS highest
FROM vehicles GROUP BY make;

-- name: Five cleanest models of each brand
SELECT make, model, engine_l, fuel_name, co2_g_km FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY make ORDER BY co2_g_km, model) AS rn
    FROM vehicles
) WHERE rn <= 5;

-- name: Average CO2 by vehicle class and brand
SELECT vehicle_class,
       ROUND(AVG(CASE WHEN make = 'BMW' THEN co2_g_km END), 1) AS bmw,
       ROUND(AVG(CASE WHEN make = 'Mercedes-Benz' THEN co2_g_km END), 1) AS mercedes_benz
FROM vehicles GROUP BY vehicle_class ORDER BY vehicle_class;

-- name: Emission tiers found by K-Means
SELECT tier, COUNT(*) AS variants, ROUND(AVG(engine_l), 1) AS avg_engine_l,
       ROUND(AVG(co2_g_km), 1) AS avg_co2
FROM vehicles GROUP BY tier ORDER BY avg_co2;

-- name: Recommendation query - cleaner cars in the same class as the BMW X5 xDrive40i
SELECT v.make, v.model, v.co2_g_km, mine.co2_g_km - v.co2_g_km AS saving_g_km
FROM vehicles v
JOIN (SELECT vehicle_class, MIN(co2_g_km) AS co2_g_km FROM vehicles WHERE model = 'X5 xDrive40i') mine
  ON v.vehicle_class = mine.vehicle_class AND v.co2_g_km < mine.co2_g_km
ORDER BY v.co2_g_km LIMIT 5;

-- name: EU fleets - laboratory (WLTP) vs real-world (OBFCM) CO2, weighted by vehicles
SELECT brand, fuel_type, SUM(vehicles) AS vehicles,
       ROUND(SUM(wltp_co2_g_km * vehicles) / SUM(vehicles), 1) AS wltp_co2,
       ROUND(SUM(obfcm_co2_g_km * vehicles) / SUM(vehicles), 1) AS real_world_co2
FROM eu_fleet GROUP BY brand, fuel_type ORDER BY brand, fuel_type;
