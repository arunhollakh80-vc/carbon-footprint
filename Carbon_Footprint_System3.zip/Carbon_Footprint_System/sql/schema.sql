-- Carbon Footprint Estimation and Recommendation System
-- Database schema (SQLite). Built by: python sql/build_database.py

DROP TABLE IF EXISTS vehicles;
DROP TABLE IF EXISTS eu_fleet;

CREATE TABLE vehicles (
    id            INTEGER PRIMARY KEY,
    make          TEXT NOT NULL CHECK (make IN ('BMW', 'Mercedes-Benz')),
    model         TEXT NOT NULL,
    vehicle_class TEXT NOT NULL,
    engine_l      REAL NOT NULL,
    cylinders     INTEGER NOT NULL,
    fuel_type     TEXT NOT NULL,
    fuel_name     TEXT,
    fuel_city     REAL NOT NULL,      -- city fuel consumption, L/100 km
    fuel_hwy      REAL NOT NULL,      -- highway fuel consumption, L/100 km
    fuel_comb     REAL NOT NULL,      -- combined fuel consumption, L/100 km
    co2_g_km      INTEGER NOT NULL,   -- tailpipe CO2, g/km
    tier          TEXT                -- K-Means emission tier: Low / Medium / High
);

CREATE TABLE eu_fleet (
    brand              TEXT NOT NULL,
    manufacturer       TEXT NOT NULL,
    year               INTEGER NOT NULL,
    fuel_type          TEXT NOT NULL,
    vehicles           INTEGER NOT NULL,
    obfcm_fuel_l_100km REAL,
    wltp_fuel_l_100km  REAL,
    fuel_gap_l_100km   REAL,
    fuel_gap_pct       REAL,
    obfcm_co2_g_km     REAL,   -- real-world CO2 (on-board fuel consumption monitoring)
    wltp_co2_g_km      REAL,   -- laboratory CO2
    co2_gap_g_km       REAL,
    co2_gap_pct        REAL
);

CREATE INDEX idx_vehicles_class ON vehicles (vehicle_class, co2_g_km);
