import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

/**
 * Carbon Footprint Estimation and Recommendation System - Java console version.
 *
 * Estimates the yearly CO2, fuel and fuel cost of a BMW or Mercedes-Benz car
 * and recommends how to cut it. Same data and formulas as the Python version:
 *   data/processed/bmw_mercedes_models.csv   (BMW and Mercedes-Benz cars)
 *   data/emission_factors.csv                (emission factors)
 *
 * It also fits a simple linear regression (least squares) in plain Java:
 *   CO2 (g/km) = a + b * fuel consumption (L/100 km)
 *
 * Compile (from the project folder):  javac -d java/out java/CarbonFootprintApp.java
 * Run:                                java -cp java/out CarbonFootprintApp
 * Run with a sample profile:          java -cp java/out CarbonFootprintApp --demo
 */
public class CarbonFootprintApp {

    /** One BMW or Mercedes-Benz model variant from the dataset. */
    static class Vehicle {
        int id; String make, model, vehicleClass, fuelType, fuelName;
        double engineL, fuelCity, fuelHwy, fuelComb, co2;
    }

    /** Answers given by the user. */
    static class Profile {
        Vehicle car;
        double kmMonth = 1000;     // kilometres driven per month
        double cityShare = 55;     // % of driving in the city (55 = the official combined rating)
        double fuelPrice = 100;    // rupees per litre
    }

    static class Tip {
        String title, text; double savingKg, savingRupees;
        Tip(String t, String x, double kg, double rs) { title = t; text = x; savingKg = kg; savingRupees = rs; }
    }

    // ------------------------------------------------------------ loading

    /** Splits one CSV line, respecting "quoted, fields". */
    static List<String> splitCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cur.append('"'); i++; }
                else quoted = !quoted;
            } else if (c == ',' && !quoted) { out.add(cur.toString()); cur.setLength(0); }
            else cur.append(c);
        }
        out.add(cur.toString());
        return out;
    }

    static Path find(String relative) throws IOException {
        for (String base : new String[] {"", "../", "../../"}) {
            Path p = Paths.get(base + relative);
            if (Files.exists(p)) return p;
        }
        throw new IOException("Cannot find " + relative
                + ". Run this program from the project folder, after python/1_prepare_data.py.");
    }

    static List<Map<String, String>> readCsv(String relative) throws IOException {
        List<String> lines = Files.readAllLines(find(relative));
        List<String> header = splitCsv(lines.get(0));
        List<Map<String, String>> rows = new ArrayList<>();
        for (String line : lines.subList(1, lines.size())) {
            if (line.trim().isEmpty()) continue;
            List<String> cells = splitCsv(line);
            Map<String, String> row = new HashMap<>();
            for (int i = 0; i < header.size() && i < cells.size(); i++) row.put(header.get(i), cells.get(i));
            rows.add(row);
        }
        return rows;
    }

    static List<Vehicle> loadVehicles() throws IOException {
        List<Vehicle> list = new ArrayList<>();
        for (Map<String, String> r : readCsv("data/processed/bmw_mercedes_models.csv")) {
            Vehicle v = new Vehicle();
            v.id = Integer.parseInt(r.get("id"));
            v.make = r.get("make"); v.model = r.get("model");
            v.vehicleClass = r.get("vehicle_class");
            v.fuelType = r.get("fuel_type"); v.fuelName = r.get("fuel_name");
            v.engineL = Double.parseDouble(r.get("engine_l"));
            v.fuelCity = Double.parseDouble(r.get("fuel_city"));
            v.fuelHwy = Double.parseDouble(r.get("fuel_hwy"));
            v.fuelComb = Double.parseDouble(r.get("fuel_comb"));
            v.co2 = Double.parseDouble(r.get("co2_g_km"));
            list.add(v);
        }
        return list;
    }

    static Map<String, Double> loadFactors() throws IOException {
        Map<String, Double> f = new HashMap<>();
        for (Map<String, String> r : readCsv("data/emission_factors.csv"))
            f.put(r.get("key"), Double.parseDouble(r.get("value")));
        return f;
    }

    // ------------------------------------------------------------ estimation

    /** Fuel (L/100 km) of a car for a given % of city driving. */
    static double blendedFuel(Vehicle v, double cityShare) {
        double s = Math.min(100, Math.max(0, cityShare)) / 100;
        return s * v.fuelCity + (1 - s) * v.fuelHwy;
    }

    /** CO2 (g/km) for that driving mix: the rated CO2 scaled by the fuel ratio. */
    static double blendedCo2(Vehicle v, double cityShare) {
        return v.co2 * blendedFuel(v, cityShare) / v.fuelComb;
    }

    static String band(double totalKg) {
        if (totalKg < 1500) return "Low";
        if (totalKg < 3000) return "Moderate";
        if (totalKg < 5000) return "High";
        return "Very high";
    }

    // ------------------------------------------------------------ recommendation

    /** Cleanest BMW / Mercedes-Benz car in the same class (E85 flex-fuel ratings are skipped). */
    static Vehicle bestAlternative(Vehicle car, List<Vehicle> all) {
        Vehicle best = null;
        for (Vehicle v : all) {
            if (!v.vehicleClass.equals(car.vehicleClass) || v.fuelType.equals("E") || v.co2 >= car.co2) continue;
            if (best == null || v.co2 < best.co2) best = v;
        }
        return best;
    }

    static List<Tip> recommend(Profile p, Map<String, Double> f, List<Vehicle> all) {
        List<Tip> tips = new ArrayList<>();
        double kmYear = p.kmMonth * 12;
        double fuel = blendedFuel(p.car, p.cityShare), co2 = blendedCo2(p.car, p.cityShare);
        double totalKg = co2 * kmYear / 1000, cost = fuel * kmYear / 100 * p.fuelPrice;

        Vehicle a = bestAlternative(p.car, all);
        if (a != null) tips.add(new Tip("Choose a cleaner car next time", String.format(Locale.US,
                "In the same class, the %s %s is rated %.0f g/km against %.0f g/km for your %s %s.",
                a.make, a.model, a.co2, p.car.co2, p.car.make, p.car.model),
                (co2 - blendedCo2(a, p.cityShare)) * kmYear / 1000,
                (fuel - blendedFuel(a, p.cityShare)) * kmYear / 100 * p.fuelPrice));
        if (p.kmMonth >= 800) tips.add(new Tip("Move one trip in five to bus or metro",
                "Taking the bus or metro for a fifth of your kilometres still cuts emissions after counting the bus.",
                0.20 * kmYear * (co2 / 1000 - f.get("bus")), 0.20 * cost));
        tips.add(new Tip("Drive smoothly",
                "Accelerate gently, keep the tyres at the right pressure and switch off instead of idling.",
                f.get("eco_driving") * totalKg, f.get("eco_driving") * cost));
        tips.add(new Tip("Combine short trips", "Plan errands into one round and skip one drive in ten.",
                0.10 * totalKg, 0.10 * cost));
        if (p.cityShare >= 70) {
            double city = p.car.co2 * p.car.fuelCity / p.car.fuelComb, hwy = p.car.co2 * p.car.fuelHwy / p.car.fuelComb;
            tips.add(new Tip("Avoid rush-hour traffic", String.format(Locale.US,
                    "Your car emits %.0f g/km in city traffic and %.0f g/km on open roads.", city, hwy),
                    0.10 * (p.cityShare / 100) * kmYear * (city - hwy) / 1000,
                    0.10 * (p.cityShare / 100) * kmYear * (p.car.fuelCity - p.car.fuelHwy) / 100 * p.fuelPrice));
        }
        tips.removeIf(t -> t.savingKg <= 0.5);
        tips.sort(Comparator.comparingDouble((Tip t) -> -t.savingKg));
        return tips;
    }

    // ------------------------------------------------------------ machine learning

    /** Least-squares line y = a + b x. Returns {a, b, r2}. */
    static double[] linearRegression(double[] x, double[] y) {
        int n = x.length;
        double mx = Arrays.stream(x).average().orElse(0), my = Arrays.stream(y).average().orElse(0);
        double sxy = 0, sxx = 0, syy = 0;
        for (int i = 0; i < n; i++) {
            sxy += (x[i] - mx) * (y[i] - my);
            sxx += (x[i] - mx) * (x[i] - mx);
            syy += (y[i] - my) * (y[i] - my);
        }
        double b = sxy / sxx, a = my - b * mx;
        return new double[] {a, b, (sxy * sxy) / (sxx * syy)};
    }

    static void printRegression(List<Vehicle> all) {
        List<Vehicle> petrol = new ArrayList<>();
        for (Vehicle v : all) if (v.fuelType.equals("Z")) petrol.add(v);
        double[] x = petrol.stream().mapToDouble(v -> v.fuelComb).toArray();
        double[] y = petrol.stream().mapToDouble(v -> v.co2).toArray();
        double[] m = linearRegression(x, y);
        System.out.printf(Locale.US,
                "%nLinear regression on %d petrol cars:%n  CO2 (g/km) = %.2f + %.2f x fuel (L/100 km)   R2 = %.4f%n",
                x.length, m[0], m[1], m[2]);
        System.out.printf(Locale.US, "  Example: a car using 9.0 L/100 km is predicted to emit %.0f g/km%n",
                m[0] + m[1] * 9.0);
    }

    // ------------------------------------------------------------ console

    static double ask(Scanner in, String text, double def) {
        System.out.printf(Locale.US, "%s [%s]: ", text, def == Math.rint(def) ? String.valueOf((long) def) : String.valueOf(def));
        String raw = in.hasNextLine() ? in.nextLine().trim() : "";
        if (raw.isEmpty()) return def;
        try { return Double.parseDouble(raw); }
        catch (NumberFormatException e) { System.out.println("  Not a number, using the default."); return def; }
    }

    static Vehicle chooseCar(Scanner in, List<Vehicle> all) {
        while (true) {
            System.out.print("Search your car model (e.g. X5, C 300, GLA): ");
            String word = in.hasNextLine() ? in.nextLine().trim().toUpperCase(Locale.ROOT) : "X5";
            List<Vehicle> hits = new ArrayList<>();
            if (!word.isEmpty())
                for (Vehicle v : all) if (v.model.toUpperCase(Locale.ROOT).contains(word) && hits.size() < 15) hits.add(v);
            if (hits.isEmpty()) { System.out.println("  No BMW / Mercedes-Benz model matches. Try a shorter name."); continue; }
            for (Vehicle v : hits)
                System.out.printf(Locale.US, "  %4d  %s %s  %.1fL %s  %.0f g/km%n", v.id, v.make, v.model, v.engineL, v.fuelName, v.co2);
            int id = (int) ask(in, "Type the id of your car", hits.get(0).id);
            for (Vehicle v : all) if (v.id == id) return v;
            return hits.get(0);
        }
    }

    static void show(Profile p, Map<String, Double> f, List<Vehicle> all) {
        double s = Math.min(100, Math.max(0, p.cityShare)) / 100, kmYear = p.kmMonth * 12;
        double perLitre = p.car.co2 / p.car.fuelComb;
        double city = s * kmYear * p.car.fuelCity * perLitre / 1000;
        double hwy = (1 - s) * kmYear * p.car.fuelHwy * perLitre / 1000;
        double total = city + hwy, litres = blendedFuel(p.car, p.cityShare) * kmYear / 100;

        System.out.printf(Locale.US, "%n================ %s %s ================%n", p.car.make, p.car.model);
        System.out.printf(Locale.US, "In your driving mix: %.1f g CO2/km, %.2f L/100 km%n",
                blendedCo2(p.car, p.cityShare), blendedFuel(p.car, p.cityShare));
        Map<String, Double> parts = new LinkedHashMap<>();
        parts.put("City driving", city); parts.put("Highway driving", hwy);
        for (Map.Entry<String, Double> e : parts.entrySet()) {
            int len = (int) Math.round(40 * e.getValue() / Math.max(total, 1));
            System.out.printf(Locale.US, "%-16s%9.1f kg  %s%n", e.getKey(), e.getValue(), "#".repeat(len));
        }
        System.out.printf(Locale.US, "%-16s%9.1f kg CO2 per year = %.2f tonnes  (%s)%n", "TOTAL", total, total / 1000, band(total));
        System.out.printf(Locale.US, "Fuel: %.0f litres a year, about Rs %,.0f%n", litres, litres * p.fuelPrice);
        long cleaner = all.stream().filter(v -> v.co2 < p.car.co2).count();
        System.out.println(cleaner + " of " + all.size() + " BMW / Mercedes-Benz models are rated lower.");

        System.out.println("\n================ RECOMMENDATIONS ================");
        int n = 1;
        for (Tip t : recommend(p, f, all))
            System.out.printf(Locale.US, "%d. %s: saves about %.0f kg CO2 and Rs %,.0f a year.%n   %s%n",
                    n++, t.title, t.savingKg, t.savingRupees, t.text);
    }

    public static void main(String[] args) throws IOException {
        List<Vehicle> vehicles = loadVehicles();
        Map<String, Double> factors = loadFactors();
        System.out.println("Car Carbon Footprint Estimation and Recommendation System (BMW / Mercedes-Benz)");
        System.out.println("Loaded " + vehicles.size() + " model variants.");

        Profile p = new Profile();
        if (args.length > 0 && args[0].equals("--demo")) {
            for (Vehicle v : vehicles) if (v.model.equalsIgnoreCase("X5 xDrive40i")) p.car = v;
            System.out.println("Demo profile: BMW X5 xDrive40i, 1000 km a month, 55% city driving.");
        } else {
            System.out.println("Press Enter to accept the value in [brackets].\n");
            Scanner in = new Scanner(System.in);
            p.car = chooseCar(in, vehicles);
            p.kmMonth = ask(in, "Kilometres driven per month", p.kmMonth);
            p.cityShare = ask(in, "How much of your driving is in the city, in % (0-100)", p.cityShare);
            p.fuelPrice = ask(in, "Fuel price in rupees per litre", p.fuelPrice);
        }
        show(p, factors, vehicles);
        printRegression(vehicles);
    }
}
