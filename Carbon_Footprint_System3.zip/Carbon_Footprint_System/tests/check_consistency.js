// Checks that the JavaScript estimator gives the same numbers as Python and Java.
// Run:  node tests/check_consistency.js
// Expected for the demo (BMW X5 xDrive40i, 1000 km a month, 55% city): 2948.4 kg CO2 a year.
const path = require("path");
globalThis.window = globalThis;
require(path.join(__dirname, "..", "web", "data.js"));
const F = require(path.join(__dirname, "..", "web", "footprint.js"));
const D = globalThis.CFS_DATA;
const car = D.models.find(m => m.model.toUpperCase() === "X5 XDRIVE40I");
const p = { ...F.DEFAULT_PROFILE };
const r = F.estimate(p, car);
console.log("Total kg:", r.total.toFixed(1), "| litres:", r.litres.toFixed(0), "| band:", r.band);
F.recommend(p, car, D.models, D.factors).forEach(t => console.log(" -", t.title, t.kg.toFixed(1), "kg, Rs", Math.round(t.rupees)));
if (Math.abs(r.total - 2948.4) > 0.1) { console.error("MISMATCH with Python/Java"); process.exit(1); }
console.log("OK: matches Python and Java");
