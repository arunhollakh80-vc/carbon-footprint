"""
Step 5 - Web server (Flask).

Serves the website and adds two API routes that use the trained models:

  GET  /                 the dashboard (web/index.html)
  POST /api/predict      predict CO2 g/km of a car from its specifications
  POST /api/estimate     footprint + recommendations for a profile (JSON)

Run:  python python/app.py     then open http://127.0.0.1:5000
"""
from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory

from footprint import estimate, load_factors, load_models, recommend

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"

app = Flask(__name__, static_folder=None)
spec_model = joblib.load(ROOT / "models" / "co2_spec_model.joblib")
tiers = joblib.load(ROOT / "models" / "kmeans_tiers.joblib")
factors = load_factors()
models = load_models(ROOT / "data" / "processed" / "bmw_mercedes_models_clustered.csv")


@app.get("/")
def index():
    return send_from_directory(WEB, "index.html")


@app.get("/<path:name>")
def static_files(name):
    return send_from_directory(WEB, name)


@app.post("/api/predict")
def predict():
    """Body: make, vehicle_class, transmission, fuel_type, engine_l, cylinders."""
    body = request.get_json(force=True)
    try:
        row = pd.DataFrame([{
            "engine_l": float(body["engine_l"]),
            "cylinders": int(body["cylinders"]),
            "make": body["make"],
            "vehicle_class": body["vehicle_class"],
            "transmission": body["transmission"],
            "fuel_type": body["fuel_type"],
        }])
    except (KeyError, ValueError, TypeError) as err:
        return jsonify({"error": f"Missing or invalid field: {err}"}), 400
    co2 = float(spec_model.predict(row)[0])
    return jsonify({"co2_g_km": round(co2, 1), "model": type(spec_model.named_steps["model"]).__name__})


@app.post("/api/estimate")
def api_estimate():
    profile = request.get_json(force=True)
    try:
        return jsonify({"estimate": estimate(profile, factors, models),
                        "recommendations": recommend(profile, factors, models)})
    except (KeyError, ValueError, TypeError) as err:
        return jsonify({"error": f"Invalid profile: {err}"}), 400


if __name__ == "__main__":
    app.run(debug=True)
