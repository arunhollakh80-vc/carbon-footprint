"""
Step 3 - Estimate your car's footprint in the terminal.

Run:  python python/3_estimate_cli.py          (asks questions)
      python python/3_estimate_cli.py --demo   (uses a sample profile)
"""
import sys

from footprint import DEFAULT_PROFILE, ROOT, estimate, load_factors, load_models, recommend


def ask(text, default, cast=float):
    raw = input(f"{text} [{default}]: ").strip()
    try:
        return cast(raw) if raw else default
    except ValueError:
        print("  Not a valid value, using the default.")
        return default


def choose_car(models):
    while True:
        word = input("Search your car model (e.g. X5, C 300, GLA): ").strip().upper()
        hits = models[models["model"].str.upper().str.contains(word, regex=False)].head(15) if word else models.head(0)
        if hits.empty:
            print("  No BMW / Mercedes-Benz model matches. Try a shorter name.")
            continue
        for _, r in hits.iterrows():
            print(f"  {r['id']:>4}  {r['make']} {r['model']}  {r['engine_l']}L {r['fuel_name']}  {r['co2_g_km']} g/km")
        return ask("Type the id of your car", int(hits.iloc[0]["id"]), int)


def show(profile, factors, models):
    r = estimate(profile, factors, models)
    car = models.loc[models["id"] == profile["car_id"]].iloc[0]
    print(f"\n================ {r['car'].upper()} ================")
    print(f"In your driving mix: {r['co2_g_km']} g CO2/km, {r['fuel_l_100km']} L/100 km")
    for name, kg in r["breakdown_kg"].items():
        bar = "#" * int(round(40 * kg / max(r["total_kg"], 1)))
        print(f"{name:<16}{kg:>9.1f} kg  {bar}")
    print(f"{'TOTAL':<16}{r['total_kg']:>9.1f} kg CO2 per year = {r['total_tonnes']} tonnes  ({r['band']})")
    print(f"Fuel: {r['fuel_litres']:.0f} litres a year, about Rs {r['fuel_cost']:,}")
    if "tier" in car:
        print(f"K-Means emission tier of this car: {car['tier']}")
    cleaner = int((models["co2_g_km"] < car["co2_g_km"]).sum())
    print(f"{cleaner} of {len(models)} BMW / Mercedes-Benz models are rated lower.")

    print("\n================ RECOMMENDATIONS ================")
    for n, t in enumerate(recommend(profile, factors, models), 1):
        print(f"{n}. {t['title']}: saves about {t['saving_kg']:.0f} kg CO2 and Rs {t['saving_rupees']:,} a year.\n   {t['tip']}")
    print("\nNote: the savings overlap, so they do not add up exactly.")


def main():
    factors = load_factors()
    clustered = ROOT / "data" / "processed" / "bmw_mercedes_models_clustered.csv"
    models = load_models(clustered) if clustered.exists() else load_models()

    if "--demo" in sys.argv:
        car_id = int(models.loc[models["model"].str.upper() == "X5 XDRIVE40I", "id"].iloc[0])
        profile = {**DEFAULT_PROFILE, "car_id": car_id}
        print("Demo profile:", profile)
        show(profile, factors, models)
        return

    print("Car Carbon Footprint Estimation and Recommendation System (BMW / Mercedes-Benz)")
    print("Press Enter to accept the value in [brackets].\n")
    d = DEFAULT_PROFILE
    p = {"car_id": choose_car(models)}
    p["km_month"] = ask("Kilometres driven per month", d["km_month"])
    p["city_share"] = ask("How much of your driving is in the city, in % (0-100)", d["city_share"])
    p["fuel_price"] = ask("Fuel price in rupees per litre", d["fuel_price"])
    show(p, factors, models)


if __name__ == "__main__":
    main()
