"""
Step 1 - Prepare the data.

Reads the main dataset (data/CO2_Emissions_Canada.csv), keeps only BMW and
Mercedes-Benz, removes duplicate rows and writes two clean files:

  data/processed/bmw_mercedes_clean.csv   one row per rated vehicle (used for ML)
  data/processed/bmw_mercedes_models.csv  one row per model variant (used by the
                                          estimator, the Java app and the website)

Run:  python python/1_prepare_data.py
"""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "CO2_Emissions_Canada.csv"
OUT = ROOT / "data" / "processed"

RENAME = {
    "Make": "make",
    "Model": "model",
    "Vehicle Class": "vehicle_class",
    "Engine Size(L)": "engine_l",
    "Cylinders": "cylinders",
    "Transmission": "transmission",
    "Fuel Type": "fuel_type",
    "Fuel Consumption City (L/100 km)": "fuel_city",
    "Fuel Consumption Hwy (L/100 km)": "fuel_hwy",
    "Fuel Consumption Comb (L/100 km)": "fuel_comb",
    "Fuel Consumption Comb (mpg)": "fuel_comb_mpg",
    "CO2 Emissions(g/km)": "co2_g_km",
}
FUEL_NAMES = {"Z": "Premium petrol", "X": "Regular petrol", "D": "Diesel",
              "E": "Ethanol (E85)", "N": "Natural gas"}
BRANDS = {"BMW": "BMW", "MERCEDES-BENZ": "Mercedes-Benz"}


def main():
    df = pd.read_csv(RAW)
    print(f"Full dataset: {len(df)} rows, {df['Make'].nunique()} makes")

    df = df[df["Make"].isin(BRANDS)].rename(columns=RENAME)
    df["make"] = df["make"].map(BRANDS)
    print(f"BMW + Mercedes-Benz rows: {len(df)}")

    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    print(f"Removed {before - len(df)} duplicate rows -> {len(df)} rows")
    print(f"Missing values: {int(df.isna().sum().sum())}")

    # The same model is sometimes spelled with different capitals
    # ("X5 xDRIVE50i" / "X5 xDrive50i"): keep the most common spelling.
    df["model"] = df.groupby(df["model"].str.upper())["model"].transform(lambda s: s.mode().iloc[0])
    df = df.drop_duplicates().reset_index(drop=True)

    df["fuel_name"] = df["fuel_type"].map(FUEL_NAMES)

    OUT.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT / "bmw_mercedes_clean.csv", index=False)

    # One row per model variant: the same variant appears in several model
    # years, so average its ratings.
    keys = ["make", "model", "vehicle_class", "engine_l", "cylinders", "fuel_type", "fuel_name"]
    models = (df.groupby(keys, as_index=False)
                .agg(fuel_city=("fuel_city", "mean"), fuel_hwy=("fuel_hwy", "mean"),
                     fuel_comb=("fuel_comb", "mean"), co2_g_km=("co2_g_km", "mean"))
                .round({"fuel_city": 1, "fuel_hwy": 1, "fuel_comb": 1, "co2_g_km": 0}))
    models["co2_g_km"] = models["co2_g_km"].astype(int)
    models = models.sort_values(["make", "model", "engine_l"]).reset_index(drop=True)
    models.insert(0, "id", models.index + 1)
    models.to_csv(OUT / "bmw_mercedes_models.csv", index=False)

    print(f"Model variants: {len(models)}")
    print(df.groupby("make")["co2_g_km"].agg(["count", "mean", "min", "max"]).round(1))
    print(f"Saved to {OUT}")


if __name__ == "__main__":
    main()
