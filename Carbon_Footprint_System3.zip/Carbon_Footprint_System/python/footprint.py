"""
Core logic: car carbon footprint estimation + hybrid recommendation.

  estimate(profile)   -> yearly CO2, fuel and fuel cost of the user's car
  recommend(profile)  -> personalised suggestions ranked by yearly CO2 saving

The project covers BMW and Mercedes-Benz cars only.

How the estimate works
  The dataset rates every car in city driving and in highway driving
  (L/100 km). The user says what share of their driving is in the city, and
  the two ratings are blended:

      fuel  = share * fuel_city + (1 - share) * fuel_hwy          (L/100 km)
      CO2   = rated CO2 * fuel / fuel_comb                        (g/km)

  CO2 is proportional to the fuel burned, so scaling the rated combined CO2
  by the fuel ratio gives the CO2 for the user's own driving mix.

The recommender is a hybrid:
  * data-driven  - the cleanest BMW / Mercedes-Benz in the same vehicle class,
                   and the K-Means emission tier of the user's car
  * rule-based   - driving-habit rules, each with a calculated saving

The same formulas are implemented in java/CarbonFootprintApp.java and
web/footprint.js, so all three give the same numbers.
"""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
MODELS_CSV = ROOT / "data" / "processed" / "bmw_mercedes_models.csv"
FACTORS_CSV = ROOT / "data" / "emission_factors.csv"

DEFAULT_PROFILE = {
    "car_id": 1,            # id from bmw_mercedes_models.csv
    "km_month": 1000,       # kilometres driven per month
    "city_share": 55,       # % of driving done in the city (55 = the official combined rating)
    "fuel_price": 100,      # rupees per litre, used for the cost figures
}


def load_factors(path=FACTORS_CSV):
    df = pd.read_csv(path)
    return dict(zip(df["key"], df["value"].astype(float)))


def load_models(path=MODELS_CSV):
    return pd.read_csv(path)


def blended(car, city_share):
    """(fuel L/100 km, CO2 g/km) of a car for a given % of city driving."""
    s = min(100.0, max(0.0, float(city_share))) / 100
    fuel = s * car["fuel_city"] + (1 - s) * car["fuel_hwy"]
    return fuel, car["co2_g_km"] * fuel / car["fuel_comb"]


def band(total_kg):
    """Project-defined bands for the yearly CO2 of one car."""
    if total_kg < 1500:
        return "Low"
    if total_kg < 3000:
        return "Moderate"
    if total_kg < 5000:
        return "High"
    return "Very high"


def estimate(profile, factors=None, models=None):
    p = {**DEFAULT_PROFILE, **profile}
    models = load_models() if models is None else models
    car = models.loc[models["id"] == int(p["car_id"])].iloc[0]
    s = min(100.0, max(0.0, float(p["city_share"]))) / 100
    km_year = float(p["km_month"]) * 12
    fuel, co2 = blended(car, p["city_share"])

    co2_per_litre_100km = car["co2_g_km"] / car["fuel_comb"]          # g/km per L/100 km
    city_kg = s * km_year * car["fuel_city"] * co2_per_litre_100km / 1000
    hwy_kg = (1 - s) * km_year * car["fuel_hwy"] * co2_per_litre_100km / 1000
    total = city_kg + hwy_kg
    litres = fuel * km_year / 100
    return {
        "car": f"{car['make']} {car['model']}",
        "co2_g_km": round(co2, 1),
        "fuel_l_100km": round(fuel, 2),
        "breakdown_kg": {"City driving": round(city_kg, 1), "Highway driving": round(hwy_kg, 1)},
        "total_kg": round(total, 1),
        "total_tonnes": round(total / 1000, 2),
        "fuel_litres": round(litres, 1),
        "fuel_cost": round(litres * float(p["fuel_price"])),
        "band": band(total),
    }


def best_alternative(car, models):
    """Cleanest BMW / Mercedes-Benz in the same vehicle class.
    E85 flex-fuel ratings are skipped: they are only valid when running on ethanol."""
    same = models[(models["vehicle_class"] == car["vehicle_class"]) &
                  (models["fuel_type"] != "E") &
                  (models["co2_g_km"] < car["co2_g_km"])]
    return None if same.empty else same.sort_values(["co2_g_km", "id"]).iloc[0]


def recommend(profile, factors=None, models=None):
    """Suggestions sorted by yearly CO2 saving (kg), each with the fuel money saved."""
    p = {**DEFAULT_PROFILE, **profile}
    f = factors or load_factors()
    models = load_models() if models is None else models
    car = models.loc[models["id"] == int(p["car_id"])].iloc[0]
    km_year = float(p["km_month"]) * 12
    price = float(p["fuel_price"])
    fuel, co2 = blended(car, p["city_share"])
    total_kg = co2 * km_year / 1000
    cost = fuel * km_year / 100 * price
    tips = []

    def add(title, text, kg, rupees):
        if kg > 0.5:
            tips.append({"title": title, "tip": text, "saving_kg": round(kg, 1), "saving_rupees": round(rupees)})

    # ---- data-driven: cleaner car in the same class -----------------------
    alt = best_alternative(car, models)
    if alt is not None:
        a_fuel, a_co2 = blended(alt, p["city_share"])
        add("Choose a cleaner car next time",
            f"In the same class, the {alt['make']} {alt['model']} is rated {int(alt['co2_g_km'])} g/km "
            f"against {int(car['co2_g_km'])} g/km for your {car['make']} {car['model']}.",
            (co2 - a_co2) * km_year / 1000, (fuel - a_fuel) * km_year / 100 * price)

    # ---- rules: driving habits --------------------------------------------
    if float(p["km_month"]) >= 800:
        add("Move one trip in five to bus or metro",
            "You drive a lot. Taking the bus or metro for a fifth of your kilometres still cuts emissions after counting the bus.",
            0.20 * km_year * (co2 / 1000 - f["bus"]), 0.20 * cost)
    add("Drive smoothly",
        "Accelerate gently, keep the tyres at the right pressure and switch off instead of idling. This saves about a tenth of your fuel.",
        f["eco_driving"] * total_kg, f["eco_driving"] * cost)
    add("Combine short trips",
        "Plan errands into one round and skip one drive in ten.",
        0.10 * total_kg, 0.10 * cost)
    if float(p["city_share"]) >= 70:
        hwy_like = car["co2_g_km"] * car["fuel_hwy"] / car["fuel_comb"]
        city_like = car["co2_g_km"] * car["fuel_city"] / car["fuel_comb"]
        add("Avoid rush-hour traffic",
            f"Your car emits {city_like:.0f} g/km in city traffic and {hwy_like:.0f} g/km on open roads. "
            "Shifting a tenth of your city driving to free-flowing hours or routes narrows that gap.",
            0.10 * (float(p["city_share"]) / 100) * km_year * (city_like - hwy_like) / 1000,
            0.10 * (float(p["city_share"]) / 100) * km_year * (car["fuel_city"] - car["fuel_hwy"]) / 100 * price)

    tips.sort(key=lambda t: -t["saving_kg"])
    return tips


if __name__ == "__main__":
    print(estimate({}))
    for t in recommend({}):
        print(f"- {t['title']}: {t['saving_kg']} kg, Rs {t['saving_rupees']} a year. {t['tip']}")
